var CONSTANTS = {};

CONSTANTS.formEntity = 'form';
CONSTANTS.formSearchableEntity = 'formSearchable';
CONSTANTS.formDataEntity = 'formData';
CONSTANTS.metaEntity = 'form_meta';
CONSTANTS.syncEntity = 'sync';
CONSTANTS.formTemplateEntity = 'formTemplate';
CONSTANTS.qrCodeSlug = 'formQRCode';

