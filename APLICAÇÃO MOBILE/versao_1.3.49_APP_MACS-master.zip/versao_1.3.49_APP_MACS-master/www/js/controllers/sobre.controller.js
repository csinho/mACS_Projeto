(function() {

  'use strict';

  angular
    .module('app')
    .controller('SobreController', SobreController);

  SobreController.$inject = [];

  function SobreController() {
    activate();

    function activate() {

    }
  }

})();
